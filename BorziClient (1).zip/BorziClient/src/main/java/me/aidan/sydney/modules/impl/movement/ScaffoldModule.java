package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.PlayerUpdateEvent;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import me.aidan.sydney.settings.impl.WhitelistSetting;
import me.aidan.sydney.utils.minecraft.InventoryUtils;
import me.aidan.sydney.utils.minecraft.MovementUtils;
import me.aidan.sydney.utils.minecraft.WorldUtils;
import net.minecraft.block.Block;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RegisterModule(name = "Scaffold", description = "Automatically places blocks under you to prevent falling.", category = Module.Category.MOVEMENT)
public class ScaffoldModule extends Module {
    public ModeSetting switchMode = new ModeSetting("Switch", "The mode that will be used for automatically switching to blocks.", "Silent", InventoryUtils.SWITCH_MODES);
    public WhitelistSetting blocks = new WhitelistSetting("Blocks", "The blocks that will be filtered out or used for scaffolding.", WhitelistSetting.Type.BLOCKS);
    public ModeSetting blocksFilter = new ModeSetting("BlocksFilter", "The way in which the block list will be used.", "Blacklist", new String[]{"Blacklist", "Whitelist"});

    public BooleanSetting fastTower = new BooleanSetting("FastTower", "Scaffolds upwards faster when holding jump.", false);
    public NumberSetting towerSpeed = new NumberSetting("TowerSpeed", "The speed at which you tower upwards.", new BooleanSetting.Visibility(fastTower, true), 0.5, 0.0, 1.0);
    public BooleanSetting whileMoving = new BooleanSetting("WhileMoving", "Allows you to tower while moving.", new BooleanSetting.Visibility(fastTower, true), false);

    public BooleanSetting onlyOnClick = new BooleanSetting("OnlyOnClick", "Only places blocks while holding right click.", false);
    public BooleanSetting rotate = new BooleanSetting("Rotate", "Rotates towards the blocks being placed.", true);

    public BooleanSetting airPlace = new BooleanSetting("AirPlace", "Allows you to place blocks in the air and modify the scaffold radius.", false);
    public NumberSetting aheadDistance = new NumberSetting("AheadDistance", "How far ahead of you the blocks will be placed.", new BooleanSetting.Visibility(airPlace, false), 0.0, 0.0, 1.0);
    public NumberSetting placeRange = new NumberSetting("PlaceRange", "The maximum range at which blocks can be placed when you are in the air.", new BooleanSetting.Visibility(airPlace, false), 4.0, 0.0, 8.0);
    public NumberSetting radius = new NumberSetting("Radius", "The radius of the scaffold.", new BooleanSetting.Visibility(airPlace, true), 0.0, 0.0, 6.0);
    public NumberSetting blocksPerTick = new NumberSetting("BlocksPerTick", "The maximum number of blocks that can be placed each tick.", new BooleanSetting.Visibility(airPlace, true), 3, 1, 20);

    public BooleanSetting render = new BooleanSetting("Render", "Renders the blocks that are being placed.", true);

    private final BlockPos.Mutable bp = new BlockPos.Mutable();

    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (onlyOnClick.getValue() && !mc.options.useKey.isPressed()) return;

        Vec3d vec = mc.player.getPos().add(mc.player.getVelocity()).add(0, -0.75, 0);
        if (airPlace.getValue()) {
            bp.set(vec.x, vec.y, vec.z);
        } else {
            Vec3d pos = mc.player.getPos();
            if (aheadDistance.getValue().doubleValue() != 0.0 && !towering() && !mc.world.getBlockState(mc.player.getBlockPos().down()).getCollisionShape(mc.world, mc.player.getBlockPos()).isEmpty()) {
                Vec3d direction = new Vec3d(Math.sin(-mc.player.getYaw() * 0.017453292F), 0, Math.cos(-mc.player.getYaw() * 0.017453292F)).multiply(aheadDistance.getValue().doubleValue(), 0, aheadDistance.getValue().doubleValue());
                if (mc.options.forwardKey.isPressed()) pos = pos.add(direction.x, 0, direction.z);
                if (mc.options.backKey.isPressed()) pos = pos.add(-direction.x, 0, -direction.z);
                if (mc.options.leftKey.isPressed()) pos = pos.add(direction.z, 0, -direction.x);
                if (mc.options.rightKey.isPressed()) pos = pos.add(-direction.z, 0, direction.x);
            }
            bp.set(pos.x, vec.y, pos.z);
        }

        if (mc.options.sneakKey.isPressed() && !mc.options.jumpKey.isPressed() && mc.player.getY() + vec.y > -1) {
            bp.setY(bp.getY() - 1);
        }

        if (bp.getY() >= mc.player.getBlockY()) {
            bp.setY(mc.player.getBlockY() - 1);
        }

        BlockPos targetBlock = bp.toImmutable();

        if (!airPlace.getValue() && WorldUtils.getDirection(bp, false) == null) {
            List<BlockPos> blockPositions = new ArrayList<>();
            for (int x = (int) (mc.player.getX() - placeRange.getValue().doubleValue()); x < mc.player.getX() + placeRange.getValue().doubleValue(); x++) {
                for (int z = (int) (mc.player.getZ() - placeRange.getValue().doubleValue()); z < mc.player.getZ() + placeRange.getValue().doubleValue(); z++) {
                    for (int y = (int) Math.max(mc.world.getBottomY(), mc.player.getY() - placeRange.getValue().doubleValue()); y < Math.min(mc.world.getHeight(), mc.player.getY() + placeRange.getValue().doubleValue()); y++) {
                        bp.set(x, y, z);
                        if (WorldUtils.getDirection(bp, false) == null) continue;
                        if (!WorldUtils.isPlaceable(bp)) continue;
                        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(bp.offset(WorldUtils.getDirection(bp, false)))) > 36) continue;
                        blockPositions.add(bp.toImmutable());
                    }
                }
            }
            if (blockPositions.isEmpty()) return;

            blockPositions.sort(Comparator.comparingDouble(position -> position.getSquaredDistance(targetBlock)));
            bp.set(blockPositions.getFirst());
        }

        if (airPlace.getValue()) {
            List<BlockPos> positions = new ArrayList<>();
            for (int x = (int) (bp.getX() - radius.getValue().doubleValue()); x <= bp.getX() + radius.getValue().doubleValue(); x++) {
                for (int z = (int) (bp.getZ() - radius.getValue().doubleValue()); z <= bp.getZ() + radius.getValue().doubleValue(); z++) {
                    BlockPos position = new BlockPos(x, bp.getY(), z);
                    if (mc.player.getPos().distanceTo(Vec3d.ofCenter(position)) <= radius.getValue().doubleValue() || (x == bp.getX() && z == bp.getZ())) {
                        positions.add(position);
                    }
                }
            }

            if (!positions.isEmpty()) {
                positions.sort(Comparator.comparingDouble(position -> mc.player.getPos().squaredDistanceTo(Vec3d.ofCenter(position))));
                int placed = 0;
                for (BlockPos position : positions) {
                    if (place(position) && ++placed >= blocksPerTick.getValue().intValue()) break;
                }
            }
        } else {
            place(bp);
        }

        BlockPos position = bp.toImmutable();
        if (fastTower.getValue() && mc.options.jumpKey.isPressed() && !mc.options.sneakKey.isPressed() && findBlockSlot(position) != -1 && (switchMode.getValue().equalsIgnoreCase("None") ? validItem(mc.player.getMainHandStack(), position) : true)) {
            Vec3d velocity = mc.player.getVelocity();
            Box playerBox = mc.player.getBoundingBox().offset(0, 1, 0);
            if (!mc.world.getBlockCollisions(mc.player, playerBox).iterator().hasNext()) {
                if (whileMoving.getValue() || !MovementUtils.isMoving()) {
                    mc.player.setVelocity(velocity.x, towerSpeed.getValue().doubleValue(), velocity.z);
                }
            } else {
                mc.player.setVelocity(velocity.x, Math.ceil(mc.player.getY()) - mc.player.getY(), velocity.z);
                mc.player.setOnGround(true);
            }
        }
    }

    public boolean towering() {
        if (!isToggled()) return false;
        if (onlyOnClick.getValue() && !mc.options.useKey.isPressed()) return false;
        if (!fastTower.getValue() || !mc.options.jumpKey.isPressed() || mc.options.sneakKey.isPressed()) return false;
        if (!whileMoving.getValue() && MovementUtils.isMoving()) return false;

        BlockPos position = mc.player.getBlockPos().down();
        int slot = findBlockSlot(position);
        if (slot == -1) return false;
        return !switchMode.getValue().equalsIgnoreCase("None") || validItem(mc.player.getMainHandStack(), position);
    }

    private boolean place(BlockPos position) {
        int slot;
        if (switchMode.getValue().equalsIgnoreCase("None")) {
            slot = mc.player.getInventory().selectedSlot;
            if (!validItem(mc.player.getMainHandStack(), position)) return false;
        } else {
            slot = findBlockSlot(position);
            if (slot == -1) return false;
        }

        Direction direction = WorldUtils.getDirection(position, false);
        if (direction == null) return false;

        int previousSlot = mc.player.getInventory().selectedSlot;
        InventoryUtils.switchSlot(switchMode.getValue(), slot, previousSlot);
        WorldUtils.placeBlock(position, direction, Hand.MAIN_HAND, rotate.getValue(), false, render.getValue());
        InventoryUtils.switchBack(switchMode.getValue(), slot, previousSlot);
        return true;
    }

    private int findBlockSlot(BlockPos position) {
        for (int i = 0; i <= 8; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (validItem(stack, position)) return i;
        }

        return -1;
    }

    private boolean validItem(ItemStack stack, BlockPos position) {
        if (!(stack.getItem() instanceof BlockItem item)) return false;

        Block block = item.getBlock();

        if (blocksFilter.getValue().equalsIgnoreCase("Blacklist")) {
            if (blocks.getWhitelist().contains(block)) return false;
        } else {
            if (!blocks.getWhitelist().contains(block)) return false;
        }

        if (!block.getDefaultState().isFullCube(mc.world, position)) return false;
        return !(block instanceof FallingBlock) || !FallingBlock.canFallThrough(mc.world.getBlockState(position));
    }
}
