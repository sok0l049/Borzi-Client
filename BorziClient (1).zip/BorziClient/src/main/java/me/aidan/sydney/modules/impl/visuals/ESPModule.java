package me.aidan.sydney.modules.impl.visuals;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.RenderOverlayEvent;
import me.aidan.sydney.events.impl.RenderWorldEvent;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ColorSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import me.aidan.sydney.utils.graphics.Renderer2D;
import me.aidan.sydney.utils.graphics.Renderer3D;
import me.aidan.sydney.utils.minecraft.EntityUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

@RegisterModule(name = "ESP", description = "Renders entities through walls.", category = Module.Category.VISUALS)
public class ESPModule extends Module {
    public BooleanSetting players = new BooleanSetting("Players", "Renders the box ESP on player entities.", true);
    public BooleanSetting hostiles = new BooleanSetting("Hostiles", "Renders the box ESP on hostile entities.", true);
    public BooleanSetting animals = new BooleanSetting("Animals", "Renders the box ESP on animal entities.", true);
    public BooleanSetting ambient = new BooleanSetting("Ambient", "Renders the box ESP on ambient entities.", false);
    public BooleanSetting invisibles = new BooleanSetting("Invisibles", "Renders the box ESP on invisible entities.", true);
    public BooleanSetting items = new BooleanSetting("Items", "Renders the box ESP on item entities.", true);
    public BooleanSetting others = new BooleanSetting("Others", "Renders the box ESP on miscellaneous entities.", false);
    public BooleanSetting ignoreSelf = new BooleanSetting("IgnoreSelf", "Ignores yourself when rendering the ESP.", true);

    public ModeSetting mode = new ModeSetting("Mode", "The rendering mode that will be used.", "Box", new String[]{"Box", "Wireframe", "2D"});
    public ModeSetting shapeMode = new ModeSetting("ShapeMode", "How the shapes are rendered.", "Both", new String[]{"Sides", "Lines", "Both", "None"});
    public NumberSetting fillOpacity = new NumberSetting("FillOpacity", "The opacity of the shape fill.", new ModeSetting.Visibility(shapeMode, "Sides", "Both"), 0.3, 0.0, 1.0);
    public NumberSetting fadeDistance = new NumberSetting("FadeDistance", "The distance from an entity where the color begins to fade.", 3.0, 0.0, 12.0);

    public BooleanSetting highlightTarget = new BooleanSetting("HighlightTarget", "Highlights the currently targeted entity differently.", false);
    public BooleanSetting targetHitbox = new BooleanSetting("TargetHitbox", "Draws the hitbox of the target entity.", new BooleanSetting.Visibility(highlightTarget, true), true);
    public ColorSetting targetColor = new ColorSetting("TargetColor", "The color that will be used for the targeted entity.", new BooleanSetting.Visibility(highlightTarget, true), new ColorSetting.Color(new Color(200, 200, 200, 255), false, false));
    public ColorSetting targetHitboxColor = new ColorSetting("TargetHitboxColor", "The color that will be used for the target entity's hitbox.", new BooleanSetting.Visibility(targetHitbox, true), new ColorSetting.Color(new Color(100, 200, 200, 255), false, false));

    public ModeSetting colorMode = new ModeSetting("ColorMode", "Determines the colors that are used for entities.", "EntityType", new String[]{"EntityType", "Distance", "Health"});
    public BooleanSetting friendOverride = new BooleanSetting("FriendOverride", "Overrides the color of friends with the friend color.", new ModeSetting.Visibility(colorMode, "Distance", "Health"), true);

    public ColorSetting playersColor = new ColorSetting("PlayersColor", "The color that will be used for player entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(255, 255, 255), false, false));
    public ColorSetting animalsColor = new ColorSetting("AnimalsColor", "The color that will be used for animal entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(25, 255, 25, 255), false, false));
    public ColorSetting waterAnimalsColor = new ColorSetting("WaterAnimalsColor", "The color that will be used for water animal entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(25, 25, 255, 255), false, false));
    public ColorSetting monstersColor = new ColorSetting("MonstersColor", "The color that will be used for hostile entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(255, 25, 25, 255), false, false));
    public ColorSetting ambientColor = new ColorSetting("AmbientColor", "The color that will be used for ambient entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(25, 25, 25, 255), false, false));
    public ColorSetting miscColor = new ColorSetting("MiscColor", "The color that will be used for miscellaneous entities.", new ModeSetting.Visibility(colorMode, "EntityType"), new ColorSetting.Color(new Color(175, 175, 175, 255), false, false));
    public ColorSetting nonLivingColor = new ColorSetting("NonLivingColor", "The color that will be used for non living entities in health mode.", new ModeSetting.Visibility(colorMode, "Health"), new ColorSetting.Color(new Color(25, 25, 25), false, false));

    private int count;

    @SubscribeEvent
    public void onRenderWorld(RenderWorldEvent event) {
        if (mc.world == null) return;
        if (mode.getValue().equalsIgnoreCase("2D")) return;

        count = 0;

        for (Entity entity : mc.world.getEntities()) {
            boolean target = drawAsTarget(entity);
            if (!target && (entity == mc.player && ignoreSelf.getValue() || !isValidEntity(entity))) continue;

            drawBoundingBox(event, entity);
            count++;
        }
    }

    private void drawBoundingBox(RenderWorldEvent event, Entity entity) {
        Vec3d renderPos = EntityUtils.getRenderPos(entity, event.getTickDelta());
        Box box = getRenderBox(entity, renderPos);

        Color color = getColor(entity);
        if (color == null) return;

        Color lineColor = color;
        Color sideColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (color.getAlpha() * fillOpacity.getValue().floatValue()));

        boolean target = drawAsTarget(entity);

        if (mode.getValue().equalsIgnoreCase("Wireframe")) {
            Renderer3D.renderBoxOutline(event.getMatrices(), box, target ? targetHitboxColor.getColor() : lineColor);
        }

        if (mode.getValue().equalsIgnoreCase("Box") || (target && targetHitbox.getValue())) {
            boolean linesOnly = target && !mode.getValue().equalsIgnoreCase("Box");
            Color line = target ? targetHitboxColor.getColor() : lineColor;

            String shape = linesOnly ? "Lines" : shapeMode.getValue();
            if (shape.equalsIgnoreCase("Sides") || shape.equalsIgnoreCase("Both")) Renderer3D.renderBox(event.getMatrices(), box, sideColor);
            if (shape.equalsIgnoreCase("Lines") || shape.equalsIgnoreCase("Both")) Renderer3D.renderBoxOutline(event.getMatrices(), box, line);
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderOverlayEvent event) {
        if (mc.world == null) return;
        if (!mode.getValue().equalsIgnoreCase("2D")) return;

        count = 0;

        for (Entity entity : mc.world.getEntities()) {
            boolean target = drawAsTarget(entity);
            if (!target && (entity == mc.player && ignoreSelf.getValue() || !isValidEntity(entity))) continue;

            Vec3d renderPos = EntityUtils.getRenderPos(entity, event.getTickDelta());
            Box box = getRenderBox(entity, renderPos);

            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = Double.MIN_VALUE, maxY = Double.MIN_VALUE;
            boolean behind = false;
            for (Vec3d corner : getCorners(box)) {
                Vec3d screen = Renderer2D.project(corner);
                if (screen.z < 0 || screen.z > 1) {
                    behind = true;
                    break;
                }

                minX = Math.min(minX, screen.x);
                minY = Math.min(minY, screen.y);
                maxX = Math.max(maxX, screen.x);
                maxY = Math.max(maxY, screen.y);
            }
            if (behind) continue;

            Color color = getColor(entity);
            if (color == null) continue;

            Color line = target ? targetHitboxColor.getColor() : color;
            Color fill = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (color.getAlpha() * fillOpacity.getValue().floatValue()));

            if ((shapeMode.getValue().equalsIgnoreCase("Sides") || shapeMode.getValue().equalsIgnoreCase("Both")) && fill.getAlpha() > 0) {
                Renderer2D.renderQuad(event.getMatrices(), (float) minX, (float) minY, (float) maxX, (float) maxY, fill);
            }

            if (shapeMode.getValue().equalsIgnoreCase("Lines") || shapeMode.getValue().equalsIgnoreCase("Both")) {
                Renderer2D.renderOutline(event.getMatrices(), (float) minX, (float) minY, (float) maxX, (float) maxY, line);
            }

            count++;
        }
    }

    public boolean drawAsTarget(Entity entity) {
        return highlightTarget.getValue() && mc.crosshairTarget instanceof EntityHitResult hitResult && hitResult.getEntity() == entity;
    }

    private boolean isValidEntity(Entity entity) {
        if (players.getValue() && entity.getType() == EntityType.PLAYER) return true;
        if (hostiles.getValue() && entity.getType().getSpawnGroup() == SpawnGroup.MONSTER) return true;
        if (animals.getValue() && (entity.getType().getSpawnGroup() == SpawnGroup.CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.WATER_AMBIENT || entity.getType().getSpawnGroup() == SpawnGroup.UNDERGROUND_WATER_CREATURE || entity.getType().getSpawnGroup() == SpawnGroup.AXOLOTLS))
            return true;
        if (ambient.getValue() && entity.getType().getSpawnGroup() == SpawnGroup.AMBIENT) return true;
        if (invisibles.getValue() && entity.isInvisible()) return true;
        if (items.getValue() && (entity.getType() == EntityType.ITEM || entity.getType() == EntityType.EXPERIENCE_BOTTLE)) return true;
        return others.getValue();
    }

    private Box getRenderBox(Entity entity, Vec3d pos) {
        return new Box(pos.x - entity.getBoundingBox().getLengthX() / 2, pos.y, pos.z - entity.getBoundingBox().getLengthZ() / 2, pos.x + entity.getBoundingBox().getLengthX() / 2, pos.y + entity.getBoundingBox().getLengthY(), pos.z + entity.getBoundingBox().getLengthZ() / 2);
    }

    private Vec3d[] getCorners(Box box) {
        return new Vec3d[]{
                new Vec3d(box.minX, box.minY, box.minZ), new Vec3d(box.maxX, box.minY, box.minZ),
                new Vec3d(box.minX, box.minY, box.maxZ), new Vec3d(box.maxX, box.minY, box.maxZ),
                new Vec3d(box.minX, box.maxY, box.minZ), new Vec3d(box.maxX, box.maxY, box.minZ),
                new Vec3d(box.minX, box.maxY, box.maxZ), new Vec3d(box.maxX, box.maxY, box.maxZ)
        };
    }

    private Color getColor(Entity entity) {
        Color color;
        double alpha = 1;

        if (drawAsTarget(entity)) {
            color = targetColor.getColor();
        } else {
            alpha = getFadeAlpha(entity);
            if (alpha == 0) return null;

            color = getEntityTypeColor(entity);
        }

        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (color.getAlpha() * alpha));
    }

    private double getFadeAlpha(Entity entity) {
        double dist = mc.gameRenderer.getCamera().getPos().squaredDistanceTo(entity.getX(), entity.getY() + entity.getEyeHeight(entity.getPose()), entity.getZ());
        double fadeDist = fadeDistance.getValue().doubleValue();
        double alpha = 1;
        if (dist <= fadeDist * fadeDist) alpha = Math.sqrt(dist) / fadeDist;
        if (alpha <= 0.075) alpha = 0;
        return alpha;
    }

    private Color getEntityTypeColor(Entity entity) {
        if (colorMode.getValue().equalsIgnoreCase("EntityType")) {
            if (entity instanceof PlayerEntity) {
                if (friendOverride.getValue() && Sydney.FRIEND_MANAGER.contains(entity.getName().getString())) {
                    return Sydney.FRIEND_MANAGER.getDefaultFriendColor();
                }
                return playersColor.getColor();
            } else {
                SpawnGroup group = entity.getType().getSpawnGroup();
                if (group == SpawnGroup.CREATURE) return animalsColor.getColor();
                if (group == SpawnGroup.WATER_CREATURE || group == SpawnGroup.WATER_AMBIENT || group == SpawnGroup.UNDERGROUND_WATER_CREATURE || group == SpawnGroup.AXOLOTLS) return waterAnimalsColor.getColor();
                if (group == SpawnGroup.MONSTER) return monstersColor.getColor();
                if (group == SpawnGroup.AMBIENT) return ambientColor.getColor();
                return miscColor.getColor();
            }
        }

        if (friendOverride.getValue() && entity instanceof PlayerEntity && Sydney.FRIEND_MANAGER.contains(entity.getName().getString())) {
            return Sydney.FRIEND_MANAGER.getDefaultFriendColor();
        }

        if (colorMode.getValue().equalsIgnoreCase("Health")) return getHealthColor(entity);
        return getDistanceColor(entity);
    }

    private Color getHealthColor(Entity entity) {
        if (!(entity instanceof LivingEntity livingEntity)) return nonLivingColor.getColor();

        float health = MathHelper.clamp(livingEntity.getHealth() / livingEntity.getMaxHealth(), 0.0f, 1.0f);
        return new Color((int) (255 * (1.0f - health)), (int) (255 * health), 0, 255);
    }

    private Color getDistanceColor(Entity entity) {
        double distance = Math.sqrt(mc.gameRenderer.getCamera().getPos().squaredDistanceTo(entity.getX(), entity.getY() + entity.getEyeHeight(entity.getPose()), entity.getZ()));
        double percent = MathHelper.clamp(distance / 16.0, 0.0, 1.0);
        return new Color((int) (255 * percent), (int) (255 * (1 - percent)), 0, 255);
    }

    @Override
    public String getMetaData() {
        return String.valueOf(count);
    }
}
