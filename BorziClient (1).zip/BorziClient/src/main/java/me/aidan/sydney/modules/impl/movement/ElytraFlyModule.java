package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.Sydney;
import me.aidan.sydney.events.SubscribeEvent;
import me.aidan.sydney.events.impl.*;
import me.aidan.sydney.mixins.accessors.MinecraftClientAccessor;
import me.aidan.sydney.mixins.accessors.PlayerMoveC2SPacketAccessor;
import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;
import me.aidan.sydney.settings.impl.BooleanSetting;
import me.aidan.sydney.settings.impl.ModeSetting;
import me.aidan.sydney.settings.impl.NumberSetting;
import me.aidan.sydney.utils.minecraft.MovementUtils;
import me.aidan.sydney.utils.system.Timer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@RegisterModule(name = "ElytraFly", description = "Turns you into a block game boeing.", category = Module.Category.MOVEMENT)
public class ElytraFlyModule extends Module {
    public ModeSetting mode = new ModeSetting("Mode", "The mode that will be used for elytra flying.", "Control", new String[]{"Control", "Boost", "Packet", "Bounce", "Pitch40"});
    public ModeSetting takeoff = new ModeSetting("Takeoff", "The mode that will be used for taking off.", "Plain", new String[]{"None", "Plain", "Strict"});

    public BooleanSetting factorize = new BooleanSetting("Factorize", "Makes the boosting relative to your pitch.", new ModeSetting.Visibility(mode, "Boost"), false);
    public BooleanSetting always = new BooleanSetting("Always", "Always boosts regardless of forward input.", new ModeSetting.Visibility(mode, "Boost"), false);
    public BooleanSetting nCPBoost = new BooleanSetting("NCPBoost", "Makes use of special boosting for NoCheatPlus.", new ModeSetting.Visibility(mode, "Boost"), true);
    public NumberSetting minBoost = new NumberSetting("MinBoost", "The minimum boost that will be applied.", new ModeSetting.Visibility(mode, "Boost"), 1.0f, 0.0f, 5.0f);
    public NumberSetting verticalBoost = new NumberSetting("VerticalBoost", "The vertical boost that will be applied.", new BooleanSetting.Visibility(nCPBoost, true), 0, 0, 10);
    public NumberSetting limit = new NumberSetting("Limit", "The maximum speed that you will be limited to.", new ModeSetting.Visibility(mode, "Boost"), 200, 0, 2000);
    public BooleanSetting autoJump = new BooleanSetting("AutoJump", "Automatically jumps while boosting.", new ModeSetting.Visibility(mode, "Boost"), false);
    public BooleanSetting inLava = new BooleanSetting("InLava", "Boosts you while flying in lava.", new ModeSetting.Visibility(mode, "Boost"), false);
    public NumberSetting lavaSpeed = new NumberSetting("LavaSpeed", "Speed", "The boost speed that will be used in lava.", new BooleanSetting.Visibility(inLava, true), 0.2f, 0.01f, 2.0f);
    public BooleanSetting autoBoost = new BooleanSetting("AutoBoost", "Automatically adjusts the boost pitch based on altitude.", new ModeSetting.Visibility(mode, "Boost"), false);
    public NumberSetting minY = new NumberSetting("MinY", "The minimum Y level for the auto boost.", new BooleanSetting.Visibility(autoBoost, true), 100, -64, 320);
    public NumberSetting add = new NumberSetting("Add", "The additional height for the auto boost.", new BooleanSetting.Visibility(autoBoost, true), 50, 0, 200);
    public NumberSetting boostPitch = new NumberSetting("BoostPitch", "The pitch that will be used when auto boosting.", new BooleanSetting.Visibility(autoBoost, true), 20, 0, 90);

    public NumberSetting speed = new NumberSetting("Speed", "The speed at which you will be flying.", new ModeSetting.Visibility(mode, "Control"), 2.0f, 0.1f, 10.0f);
    public ModeSetting vertical = new ModeSetting("Vertical", "The mode that will be used for vertical control.", new ModeSetting.Visibility(mode, "Control"), "Plain", new String[]{"None", "Plain", "Manual", "Strict"});
    public NumberSetting vSpeed = new NumberSetting("VerticalSpeed", "Speed", "The speed at which you will be flying vertically.", new ModeSetting.Visibility(vertical, "Plain", "Manual", "Strict"), 1.0f, 0.1f, 5.0f);
    public NumberSetting vPitch = new NumberSetting("VerticalPitch", "Pitch", "The pitch that will be used while flying vertically.", new ModeSetting.Visibility(vertical, "Strict"), 51, 0, 90);
    public BooleanSetting antiKick = new BooleanSetting("AntiKick", "Prevents you from getting kicked by the anticheat.", new ModeSetting.Visibility(mode, "Control"), false);
    public NumberSetting glide = new NumberSetting("Glide", "The amount that you will slowly fall by.", new ModeSetting.Visibility(mode, "Control", "Packet"), 0.01f, 0.0f, 1.0f);
    public BooleanSetting spoofPitch = new BooleanSetting("SpoofPitch", "Spoofs the pitch that gets sent to the server.", new ModeSetting.Visibility(mode, "Control"), false);
    public NumberSetting pitch = new NumberSetting("Pitch", "The pitch that will be sent to the server.", new BooleanSetting.Visibility(spoofPitch, true), 12, -90, 90);
    public BooleanSetting accelerate = new BooleanSetting("Accelerate", "Gradually increases your speed over time.", new ModeSetting.Visibility(mode, "Control", "Packet"), false);
    public NumberSetting verAccelMin = new NumberSetting("VerticalAccelMin", "Min", "The minimum vertical speed while accelerating.", new BooleanSetting.Visibility(accelerate, true), 0.1f, 0.0f, 5.0f);
    public NumberSetting accelMin = new NumberSetting("AccelMin", "Min", "The minimum speed while accelerating.", new BooleanSetting.Visibility(accelerate, true), 0.5f, 0.0f, 5.0f);
    public NumberSetting accelTime = new NumberSetting("AccelTime", "Time", "The time it takes to reach the target speed.", new BooleanSetting.Visibility(accelerate, true), 1.0f, 0.1f, 5.0f);

    public BooleanSetting antiAfk = new BooleanSetting("AntiAfk", "Prevents you from getting kicked for being idle.", new ModeSetting.Visibility(mode, "Packet"), false);
    public BooleanSetting verticalPacket = new BooleanSetting("VerticalPacket", "Allows you to control your vertical movement.", new ModeSetting.Visibility(mode, "Packet"), false);

    public BooleanSetting bounceAutoJump = new BooleanSetting("AutoJump", "Automatically jumps for you.", new ModeSetting.Visibility(mode, "Bounce"), true);
    public ModeSetting yawLock = new ModeSetting("YawLock", "Whether to enable yaw locking.", new ModeSetting.Visibility(mode, "Bounce"), "Smart", new String[]{"None", "Smart", "Simple"});
    public NumberSetting yaw = new NumberSetting("Yaw", "The yaw angle to look at when using simple yaw locking.", new ModeSetting.Visibility(yawLock, "Simple"), 0, 0, 360);
    public BooleanSetting bouncePitchLock = new BooleanSetting("PitchLock", "Whether to lock your pitch angle.", new ModeSetting.Visibility(mode, "Bounce"), true);
    public NumberSetting bouncePitch = new NumberSetting("Pitch", "The pitch angle to look at when bouncing.", new BooleanSetting.Visibility(bouncePitchLock, true), 85, 0, 90);
    public BooleanSetting restart = new BooleanSetting("Restart", "Restarts flying with the elytra when rubberbanding.", new ModeSetting.Visibility(mode, "Bounce"), true);
    public NumberSetting restartDelay = new NumberSetting("RestartDelay", "How many ticks to wait before restarting the elytra again after rubberbanding.", new BooleanSetting.Visibility(restart, true), 7, 0, 20);
    public BooleanSetting sprintConstantly = new BooleanSetting("SprintConstantly", "Sprints all the time. If turned off, it will only sprint when the player is touching the ground.", new ModeSetting.Visibility(mode, "Bounce"), true);
    public BooleanSetting manualTakeoff = new BooleanSetting("ManualTakeoff", "Does not automatically take off.", new ModeSetting.Visibility(mode, "Bounce"), false);

    public NumberSetting pitch40LowerBounds = new NumberSetting("LowerBounds", "The bottom height boundary for pitch40.", new ModeSetting.Visibility(mode, "Pitch40"), 180, -64, 360);
    public NumberSetting pitch40UpperBounds = new NumberSetting("UpperBounds", "The upper height boundary for pitch40.", new ModeSetting.Visibility(mode, "Pitch40"), 220, -64, 360);
    public NumberSetting pitch40RotateUp = new NumberSetting("RotateSpeedUp", "The speed for pitch rotation upwards (degrees per tick).", new ModeSetting.Visibility(mode, "Pitch40"), 5.45, 1.0, 20.0);
    public NumberSetting pitch40RotateDown = new NumberSetting("RotateSpeedDown", "The speed for pitch rotation downwards (degrees per tick).", new ModeSetting.Visibility(mode, "Pitch40"), 0.90, 0.5, 2.0);

    public BooleanSetting infDurability = new BooleanSetting("InfDurability", "Prevents your elytra from having any durability used up.", new ModeSetting.Visibility(mode, "Control", "Boost", "Packet", "Bounce", "Pitch40"), false);
    public BooleanSetting muteElytra = new BooleanSetting("MuteElytra", "Mutes the elytra equip sounds.", new ModeSetting.Visibility(mode, "Control", "Boost", "Packet", "Bounce", "Pitch40"), false);
    public BooleanSetting grimDurability = new BooleanSetting("GrimDurability", "Uses the durability bypass catered to the Grim anticheat.", false);

    private final Timer takeoffTimer = new Timer();
    private final Timer timer = new Timer();
    private final Timer timer2 = new Timer();

    private boolean flag;
    private boolean fireworkPending;
    private boolean interacting;

    private long controlTime = 0;
    private long controlTime2 = 0;
    private Vec3d vec3d = Vec3d.ZERO;
    private int strictTick;
    private boolean strictFlag;
    private boolean strictFlag2;

    private int strictVerticalTick;

    private float boostValue;

    // Bounce state
    private boolean rubberbanded;
    private int tickDelay;
    private double prevFov = 1.0;
    private boolean lastJumpPressed;
    private boolean incrementJumpTimer;
    private int jumpTimer;

    // Pitch40 state
    private boolean pitchingDown = true;
    private float pitch40Pitch = 37.72f;

    private boolean manualVertical() {
        return (mc.player.input.playerInput.jump() || mc.player.input.playerInput.sneak()) && vertical.getValue().equalsIgnoreCase("Manual") && mc.player.isGliding() && hasElytra();
    }

    private boolean isPacketFlying() {
        if (mc.player.input == null) return false;
        if (verticalPacket.getValue() && mc.player.input.playerInput.jump()) return false;
        return isToggled() && !mc.player.isOnGround() && mode.getValue().equalsIgnoreCase("Packet") && hasElytra();
    }

    private boolean hasElytra() {
        return mc.player.getInventory().getArmorStack(EquipmentSlot.CHEST.getEntitySlotId()).isOf(Items.ELYTRA);
    }

    private boolean isMoving() {
        return mc.player.sidewaysSpeed != 0.0f || mc.player.forwardSpeed != 0.0f;
    }

    private boolean notInLiquid() {
        return !mc.player.isTouchingWater() && !mc.player.isInLava() && !MovementUtils.isMoving();
    }

    private boolean canStartFlying() {
        return !mc.player.getAbilities().flying && !mc.player.hasVehicle() && !mc.player.isClimbing() && hasElytra() && !mc.player.isTouchingWater() && !mc.player.hasStatusEffect(StatusEffects.LEVITATION) && mc.player.input.playerInput.jump();
    }

    private boolean isSlowedByItem() {
        return mc.player.isUsingItem() && (!Sydney.MODULE_MANAGER.getModule(NoSlowModule.class).isToggled() || !Sydney.MODULE_MANAGER.getModule(NoSlowModule.class).items.getValue());
    }

    @Override
    public void onEnable() {
        flag = true;
        strictTick = 0;
        controlTime = System.currentTimeMillis();
        controlTime2 = System.currentTimeMillis();

        if (mode.getValue().equalsIgnoreCase("Bounce")) {
            rubberbanded = false;
            tickDelay = restartDelay.getValue().intValue();
            lastJumpPressed = false;
            incrementJumpTimer = false;
            jumpTimer = 0;
            try {
                prevFov = mc.options.getFovEffectScale().getValue();
            } catch (Exception ignored) {
                prevFov = 1.0;
            }
        }

        if (mode.getValue().equalsIgnoreCase("Pitch40")) {
            if (mc.player.getY() < pitch40UpperBounds.getValue().doubleValue()) {
                Sydney.CHAT_MANAGER.error("Player must be above upper bounds!");
                setToggled(false);
                return;
            } else if (mc.player.getY() - 40 < pitch40LowerBounds.getValue().doubleValue()) {
                Sydney.CHAT_MANAGER.error("Player must be at least 40 blocks above the lower bounds!");
                setToggled(false);
                return;
            }

            pitchingDown = true;
            pitch40Pitch = 37.72f;
        }
    }

    @Override
    public void onDisable() {
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.player.setSprinting(false);
        mc.player.getAbilities().flying = false;
        mc.player.getAbilities().setFlySpeed(0.05F);

        if (mode.getValue().equalsIgnoreCase("Bounce")) {
            rubberbanded = false;
            incrementJumpTimer = false;
            jumpTimer = 0;
            if (prevFov != 0 && !sprintConstantly.getValue()) {
                try {
                    mc.options.getFovEffectScale().setValue(prevFov);
                } catch (Exception ignored) {
                }
            }
        }
    }

    @Override
    public String getMetaData() {
        return mode.getValue();
    }

    @SubscribeEvent
    public void onPlayerUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (mc.player.isOnGround()) {
            strictFlag = false;
        } else if (mc.player.isGliding()) {
            strictFlag = true;
        }

        boolean jumping = mc.player.input.playerInput.jump();
        if (takeoff.getValue().equalsIgnoreCase("Strict")) {
            jumping = !mc.player.isOnGround() && mc.player.getVelocity().getY() < 0.1;
        }

        if (jumping || strictFlag2) {
            tryTakeoff();
            strictFlag2 = !mc.player.isGliding();
        }
    }

    @SubscribeEvent
    public void onPlayerMove(PlayerMoveEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (isSlowedByItem()) return;

        switch (mode.getValue().toLowerCase()) {
            case "control" -> controlMove(event);
            case "boost" -> boostMove(event);
            case "packet" -> packetMove(event);
        }
    }

    private void controlMove(PlayerMoveEvent event) {
        if (!mc.player.isGliding() || manualVertical() || !hasElytra()) {
            controlTime = System.currentTimeMillis();
            return;
        }

        if (!isMoving()) {
            controlTime = System.currentTimeMillis();
        }

        double currentSpeed;
        float vSpeedValue = vSpeed.getValue().floatValue();
        if (accelerate.getValue()) {
            currentSpeed = accelerate(speed.getValue().doubleValue(), accelMin.getValue().doubleValue(), accelTime.getValue().doubleValue(), controlTime);
            vSpeedValue = (float) accelerate(vSpeed.getValue().doubleValue(), verAccelMin.getValue().doubleValue(), accelTime.getValue().doubleValue(), controlTime2);
        } else {
            currentSpeed = speed.getValue().doubleValue();
        }

        double[] movement = getMovementVector(mc.player.getYaw(), mc.player.input.movementForward, mc.player.input.movementSideways, currentSpeed);

        double y = mc.player.getVelocity().getY();
        if (mc.player.input.playerInput.jump() && mc.player.isGliding()) {
            if (vertical.getValue().equalsIgnoreCase("Strict")) {
                strictVerticalTick++;
            }

            if (vertical.getValue().equalsIgnoreCase("Plain")) {
                y = vSpeedValue;
            } else if (vertical.getValue().equalsIgnoreCase("Strict") && isMoving()) {
                strictVerticalBoost();
                y = mc.player.getVelocity().getY();
            }
        } else if (mc.player.input.playerInput.sneak()) {
            strictVerticalTick = 0;
            y = -vSpeedValue;
        } else {
            strictVerticalTick = 0;
            y = 0.0;
            if (!mc.player.verticalCollision && glide.getValue().floatValue() != 0.0f) {
                y = -glide.getValue().floatValue();
            }
        }

        if (antiKick.getValue() && strictVerticalTick == 0 && mc.player.age % 4 == 0) {
            y -= 0.0001;
        }

        Vec3d velocity = new Vec3d(movement[0], y, movement[1]);
        mc.player.setVelocity(velocity);
        vec3d = velocity;
        event.setMovement(velocity);
        event.setCancelled(true);
    }

    private void boostMove(PlayerMoveEvent event) {
        float limitValue = limit.getValue().floatValue();
        float maxLimit = limit.getMaximum().floatValue();
        if (limitValue > 200 && limitValue < maxLimit && mc.player.getGlidingTicks() <= 5 && nCPBoost.getValue()) {
            limitValue = 200;
        }

        if (limitValue != maxLimit || mc.player.getGlidingTicks() <= 5 && nCPBoost.getValue()) {
            Vec3d movement = event.getMovement();
            double horizontal = Math.hypot(movement.getX(), movement.getZ());
            if (horizontal * 20.0 * 3.6 > limitValue) {
                Vec3d normalized = movement.normalize();
                event.setMovement(new Vec3d(normalized.getX() * limitValue / 3.6 / 20.0, movement.getY(), normalized.getZ() * limitValue / 3.6 / 20.0));
                event.setCancelled(true);
            }
        }
    }

    private void packetMove(PlayerMoveEvent event) {
        if (!isPacketFlying()) return;

        if (!isMoving()) {
            controlTime = System.currentTimeMillis();
        }

        double speedValue;
        if (accelerate.getValue()) {
            speedValue = accelerate(speed.getValue().doubleValue(), accelMin.getValue().doubleValue(), accelTime.getValue().doubleValue(), controlTime);
        } else {
            speedValue = speed.getValue().doubleValue();
        }

        double[] movement = getMovementVector(mc.player.getYaw(), mc.player.input.movementForward, mc.player.input.movementSideways, speedValue);
        double y = -glide.getValue().floatValue();

        if (mc.player.input.playerInput.sneak()) {
            y = -0.5;
        }

        if (antiAfk.getValue() && movement[0] == 0.0 && movement[1] == 0.0 && timer.hasTimeElapsed(2500)) {
            movement[0] = Math.sin(Math.toRadians(mc.player.age % 360)) * 0.03;
            movement[1] = Math.cos(Math.toRadians(mc.player.age % 360)) * 0.03;
        } else if (isMoving()) {
            timer.reset();
        }

        Vec3d velocity = new Vec3d(movement[0], y, movement[1]);
        mc.player.setVelocity(velocity);
        event.setMovement(velocity);
        event.setCancelled(true);

        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
    }

    @SubscribeEvent
    public void onUpdateMovementPost(UpdateMovementEvent.Post event) {
        if (mc.player == null || mc.world == null) return;
        if (isSlowedByItem()) return;

        if (mode.getValue().equalsIgnoreCase("Boost")) {
            boostTick();
        }
    }

    private void boostTick() {
        if (!hasElytra() || mc.player.isTouchingWater()) return;

        boolean jumping = mc.player.input.playerInput.jump();
        if (takeoff.getValue().equalsIgnoreCase("Strict")) {
            jumping = !mc.player.isOnGround() && mc.player.getVelocity().getY() < 0.1;
        }

        if (mc.player.isGliding()) {
            timer.reset();
        }

        if ((jumping || !timer.hasTimeElapsed(1500)) && !mc.player.isGliding() && mc.player.getHealth() > 0 && hasElytra()) {
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            mc.player.startGliding();
        }

        if (mc.player.isGliding()) {
            if (autoBoost.getValue()) {
                updateAutoBoost();
            }

            float boost = minBoost.getValue().floatValue() * 0.1f;
            float yawRadians = (float) Math.toRadians(mc.player.getYaw());

            updateNCPBoost();

            if (inLava.getValue() && mc.player.isInLava()) {
                boost = 0.2f * lavaSpeed.getValue().floatValue();
            }

            boolean boosting = factorize.getValue() ? mc.player.getPitch() <= 0.0f : mc.options.forwardKey.isPressed() || always.getValue();
            if (boosting) {
                mc.player.addVelocity(MathHelper.sin(yawRadians) * -boost, 0.0, MathHelper.cos(yawRadians) * boost);
            } else if (mc.options.backKey.isPressed()) {
                mc.player.addVelocity(MathHelper.sin(yawRadians) * boost, 0.0, MathHelper.cos(yawRadians) * -boost);
            }
        }
    }

    private void updateNCPBoost() {
        if (mc.player.getPitch() < 0.0f && nCPBoost.getValue()) {
            int fallTicks = mc.player.getGlidingTicks();
            if (fallTicks % 6 > 2 || fallTicks >= 1 && fallTicks < 10) {
                return;
            }

            Sydney.ROTATION_MANAGER.rotate(mc.player.getYaw(), 0.0f, 10000);
        }
    }

    private void updateAutoBoost() {
        float pitch = boostPitch.getValue().floatValue();
        if (mc.player.getY() >= minY.getValue().doubleValue() + add.getValue().doubleValue()) {
            flag = true;
        }

        if (mc.player.getY() <= minY.getValue().doubleValue() && flag) {
            flag = false;
        }

        if (flag) {
            boostValue += 4.0f;
        } else {
            boostValue -= 4.0f;
        }

        boostValue = MathHelper.clamp(boostValue, -pitch, Math.max(pitch, mc.player.getPitch()));
    }

    // Bounce (ported from Meteor Client, credit to Luna's Elytra Recast)

    private boolean checkBounceConditions() {
        return !mc.player.getAbilities().flying && !mc.player.hasVehicle() && !mc.player.isClimbing()
            && !mc.player.isTouchingWater() && !mc.player.hasStatusEffect(StatusEffects.LEVITATION) && hasElytra();
    }

    private void bounceTick() {
        if (mc.options.jumpKey.isPressed() && !mc.player.isGliding() && !manualTakeoff.getValue()) {
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        }

        if (!checkBounceConditions()) return;

        if (!rubberbanded) {
            if (prevFov != 0 && !sprintConstantly.getValue()) {
                try {
                    mc.options.getFovEffectScale().setValue(0.0);
                } catch (Exception ignored) {
                }
            }
            if (bounceAutoJump.getValue()) mc.options.jumpKey.setPressed(true);
            mc.options.forwardKey.setPressed(true);
            mc.player.setYaw(getYawDirection());
            if (bouncePitchLock.getValue()) mc.player.setPitch(bouncePitch.getValue().floatValue());
        }

        if (!sprintConstantly.getValue()) {
            // Sprinting all the time (when not on ground) makes it rubberband on certain anticheats.
            if (mc.player.isGliding()) mc.player.setSprinting(mc.player.isOnGround());
            else mc.player.setSprinting(true);
        }

        // Rubberbanding
        if (rubberbanded && restart.getValue()) {
            if (tickDelay > 0) {
                tickDelay--;
            } else {
                redeploy();
                rubberbanded = false;
                tickDelay = restartDelay.getValue().intValue();
            }
        }

        bounceAutoTakeoff();
    }

    private void bounceAutoTakeoff() {
        if (incrementJumpTimer) jumpTimer++;

        boolean jumpPressed = mc.options.jumpKey.isPressed();

        if (!manualTakeoff.getValue() && jumpPressed) {
            if (!lastJumpPressed && !mc.player.isGliding()) {
                jumpTimer = 0;
                incrementJumpTimer = true;
            }

            if (jumpTimer >= 8) {
                jumpTimer = 0;
                incrementJumpTimer = false;
                mc.player.setJumping(false);
                mc.player.setSprinting(true);
                mc.player.jump();
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
        }

        lastJumpPressed = jumpPressed;
    }

    private float getYawDirection() {
        return switch (yawLock.getValue()) {
            case "Simple" -> yaw.getValue().floatValue();
            case "Smart" -> Math.round((mc.player.getYaw() + 1.0f) / 45.0f) * 45.0f;
            default -> mc.player.getYaw();
        };
    }

    // Pitch40 (ported from Meteor Client)

    private float randPitch(float pitch, float bound) {
        return (float) (pitch + (bound * (Math.random() - 0.5)));
    }

    private void pitch40Tick() {
        /*
        When descending, look at 37.72 deg
        When ascending, look up at -54.77 at 5.45 degree/tick, then lower at 0.90 deg/tick until at 37.72
        */

        if (pitchingDown && mc.player.getY() <= pitch40LowerBounds.getValue().doubleValue()) {
            pitchingDown = false;
        } else if (!pitchingDown && mc.player.getY() >= pitch40UpperBounds.getValue().doubleValue()) {
            pitchingDown = true;
        }

        // Pitch upwards
        if (!pitchingDown) {
            pitch40Pitch -= randPitch(pitch40RotateUp.getValue().floatValue(), 1.0f);

            if (pitch40Pitch < -54.77f) {
                pitch40Pitch = -54.77f;
                pitchingDown = true;
            }
            // Pitch downwards
        } else if (pitch40Pitch < 37.72f) {
            pitch40Pitch += randPitch(pitch40RotateDown.getValue().floatValue(), 0.50f);
        }

        mc.player.setPitch(pitch40Pitch);
    }

    @SubscribeEvent
    public void onPlayerTravel(PlayerTravelEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (mode.getValue().equalsIgnoreCase("Bounce") && checkBounceConditions() && sprintConstantly.getValue()) {
            mc.player.setSprinting(true);
        }
    }

    @SubscribeEvent
    public void onKeyboardTick(KeyboardTickEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (mode.getValue().equalsIgnoreCase("Boost") && autoJump.getValue() && mc.player.isGliding()) {
            PlayerInput input = mc.player.input.playerInput;
            mc.player.input.playerInput = new PlayerInput(input.forward(), input.backward(), input.left(), input.right(), true, input.sneak(), input.sprint());
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (event.getPacket() instanceof ClientCommandC2SPacket packet && packet.getMode() == ClientCommandC2SPacket.Mode.START_FALL_FLYING) {
            if (mode.getValue().equalsIgnoreCase("Bounce") && !sprintConstantly.getValue() && checkBounceConditions()) {
                mc.player.setSprinting(true);
            }
        }

        if (event.getPacket() instanceof PlayerMoveC2SPacket packet && packet.changesLook() && mc.player.isGliding()) {
            if (mode.getValue().equalsIgnoreCase("Control")) {
                controlPacket(packet);
            }
        }
    }

    private void controlPacket(PlayerMoveC2SPacket packet) {
        if (manualVertical() || !mc.player.isGliding() || !hasElytra()) return;

        if (mc.player.input.playerInput.jump() || mc.player.input.playerInput.sneak() && vertical.getValue().equalsIgnoreCase("Plain")) {
            ((PlayerMoveC2SPacketAccessor) packet).setPitch(getVerticalPitch());
            return;
        }

        if (!isMoving()) return;

        if (spoofPitch.getValue()) {
            ((PlayerMoveC2SPacketAccessor) packet).setPitch(pitch.getValue().floatValue());
        }

        if (strictVerticalTick > 0) {
            ((PlayerMoveC2SPacketAccessor) packet).setPitch(-vPitch.getValue().floatValue());
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketReceiveEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (event.getPacket() instanceof EntitySpawnS2CPacket packet && packet.getEntityType() == EntityType.FIREWORK_ROCKET) {
            Vec3d position = new Vec3d(packet.getX(), packet.getY(), packet.getZ());
            if (position.squaredDistanceTo(mc.player.getPos()) <= 36.0) {
                timer2.reset();
            }
        }

        // Rubberband detection for bounce
        if (mode.getValue().equalsIgnoreCase("Bounce") && event.getPacket() instanceof PlayerPositionLookS2CPacket) {
            rubberbanded = true;
            mc.player.stopGliding();
        }
    }

    @SubscribeEvent
    public void onMouseInput(MouseInputEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (!interacting && mc.player.getMainHandStack().getItem() == Items.FIREWORK_ROCKET) {
            fireworkPending = true;
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (infDurability.getValue() && timer2.hasTimeElapsed(200) && !mode.getValue().equalsIgnoreCase("Bounce")) {
            if (hasElytra()) {
                mc.interactionManager.clickSlot(0, 6, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(0, 6, 0, SlotActionType.PICKUP, mc.player);
                redeploy();
            }
        }

        if (mode.getValue().equalsIgnoreCase("Bounce")) {
            bounceTick();
        } else if (mode.getValue().equalsIgnoreCase("Pitch40")) {
            pitch40Tick();
        }
    }

    @SubscribeEvent
    public void onTick$Firework(TickEvent event) {
        if (mc.player == null || mc.world == null) return;

        if (fireworkPending && timer.hasTimeElapsed(150)) {
            interacting = true;
            ((MinecraftClientAccessor) mc).invokeDoItemUse();
            interacting = false;
            fireworkPending = false;
        }
    }

    private void redeploy() {
        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        mc.player.startGliding();
    }

    private void tryTakeoff() {
        if (!mc.player.isGliding() && !mc.player.isOnGround() && !takeoff.getValue().equalsIgnoreCase("None")) {
            if (takeoffTimer.hasTimeElapsed(100L)) {
                mc.player.startGliding();
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                takeoffTimer.reset();
            }
        }
    }

    private float getVerticalPitch() {
        if (mc.player.input.playerInput.jump()) {
            return -vPitch.getValue().floatValue();
        }

        return 0.0f;
    }

    private void strictVerticalBoost() {
        double pitchRadians = Math.toRadians(-vPitch.getValue().floatValue());
        Vec3d direction = new Vec3d(-Math.sin(Math.toRadians(mc.player.getYaw())) * Math.cos(pitchRadians), -Math.sin(pitchRadians), Math.cos(Math.toRadians(mc.player.getYaw())) * Math.cos(pitchRadians));
        Vec3d velocity = vec3d;
        double horizontalLength = velocity.horizontalLength();
        double directionHorizontal = direction.horizontalLength();
        double directionLength = direction.length();
        double cos = Math.cos(pitchRadians);
        cos = cos * cos * Math.min(1.0, directionLength / 0.4);

        velocity = velocity.add(0.0, 0.08 * (-1.0 + cos * 0.75), 0.0);

        if (pitchRadians < 0.0 && directionHorizontal > 0.0) {
            double delta = horizontalLength * -Math.sin(pitchRadians) * 0.04;
            velocity = velocity.add(-direction.getX() * delta / directionHorizontal, delta * 3.2, -direction.getZ() * delta / directionHorizontal);
        }

        mc.player.setVelocity(velocity.multiply(0.99, 0.98, 0.99));
        vec3d = mc.player.getVelocity();
    }

    private double accelerate(double target, double minimum, double time, long startTime) {
        if (minimum >= target) return target;

        double progress = MathHelper.clamp((System.currentTimeMillis() - startTime) / (time * 1000.0), 0.0, 1.0);
        double current = minimum + (target - minimum) * progress;
        return Math.min(current, target);
    }

    private double[] getMovementVector(float yaw, float forward, float sideways, double speed) {
        if (forward == 0.0f && sideways == 0.0f) return new double[]{0.0, 0.0};

        float direction = yaw;
        if (forward != 0.0f) {
            if (sideways > 0.0f) {
                direction = yaw + (forward > 0.0f ? -45 : 45);
            } else if (sideways < 0.0f) {
                direction = yaw + (forward > 0.0f ? 45 : -45);
            }

            sideways = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }

        double x = forward * speed * -Math.sin(Math.toRadians(direction)) + sideways * speed * Math.cos(Math.toRadians(direction));
        double z = forward * speed * Math.cos(Math.toRadians(direction)) - sideways * speed * -Math.sin(Math.toRadians(direction));
        return new double[]{x, z};
    }
}